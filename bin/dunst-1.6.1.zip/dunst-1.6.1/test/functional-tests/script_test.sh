#!/bin/bash

notify-send "Success" "ooooh yeah"
